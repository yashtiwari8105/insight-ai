import React, { useCallback, useState } from 'react';
import { Upload, FileText, AlertCircle } from 'lucide-react';
import { MAX_CSV_SIZE_BYTES } from '../constants';

interface FileUploadProps {
  onFileSelect: (content: string, fileName: string) => void;
  disabled?: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, disabled }) => {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = useCallback((file: File) => {
    setError(null);
    if (!file.name.endsWith('.csv')) {
      setError("Please upload a valid CSV file.");
      return;
    }
    if (file.size > MAX_CSV_SIZE_BYTES) {
      setError(`File size exceeds limit of ${MAX_CSV_SIZE_BYTES / 1024 / 1024}MB.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      onFileSelect(text, file.name);
    };
    reader.readAsText(file);
  }, [onFileSelect]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, [handleFile]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  }, [handleFile]);

  return (
    <div className="w-full max-w-2xl mx-auto mb-8 animate-fade-in-up">
      <div
        className={`relative group flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-2xl transition-all duration-300 ease-in-out backdrop-blur-sm
          ${dragActive 
            ? 'border-blue-500 bg-blue-500/10 shadow-[0_0_30px_rgba(59,130,246,0.3)]' 
            : 'border-slate-700 bg-slate-900/50 hover:border-blue-400 hover:bg-slate-800/80'}
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
        `}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input
          type="file"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
          onChange={handleChange}
          accept=".csv"
          disabled={disabled}
        />
        
        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center pointer-events-none">
          <div className={`p-4 rounded-full mb-4 transition-colors duration-300
            ${dragActive ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-800 text-slate-400 group-hover:bg-blue-500/20 group-hover:text-blue-400'}`}>
            <Upload className="w-8 h-8" />
          </div>
          <p className="mb-2 text-xl font-medium text-slate-200 group-hover:text-white transition-colors">
            {dragActive ? "Drop CSV to Analyze" : "Upload Dataset"}
          </p>
          <p className="text-sm text-slate-500 group-hover:text-slate-400 transition-colors">
            CSV format supported • Max 5MB
          </p>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 mt-4 text-red-400 bg-red-900/20 border border-red-900/50 p-3 rounded-lg text-sm font-medium animate-fadeIn">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
};

export default FileUpload;