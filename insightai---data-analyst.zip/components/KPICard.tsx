import React from 'react';
import { KPI } from '../types';
import { DollarSign, Users, TrendingUp, Activity, Package } from 'lucide-react';

interface KPICardProps {
  kpi: KPI;
}

const KPICard: React.FC<KPICardProps> = ({ kpi }) => {
  const { label, value, trend, trendColor, icon } = kpi;

  const getIcon = () => {
    switch (icon) {
      case 'dollar': return <DollarSign className="w-5 h-5" />;
      case 'users': return <Users className="w-5 h-5" />;
      case 'trend': return <TrendingUp className="w-5 h-5" />;
      case 'activity': return <Activity className="w-5 h-5" />;
      case 'box': return <Package className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  const trendColorClass = 
    trendColor === 'green' ? 'text-emerald-400' :
    trendColor === 'red' ? 'text-red-400' :
    'text-slate-400';

  return (
    <div className="relative group p-[1px] rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 overflow-hidden hover:shadow-[0_0_20px_rgba(59,130,246,0.15)] transition-shadow duration-300">
      {/* Gradient border effect via background layer */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 group-hover:from-blue-600/50 group-hover:via-purple-600/50 group-hover:to-slate-900 transition-colors duration-500"></div>
      
      {/* Inner Content */}
      <div className="relative h-full bg-slate-950/90 backdrop-blur-xl rounded-[15px] p-5 flex flex-col justify-between">
        <div className="flex justify-between items-start mb-4">
          <div className="p-2 bg-slate-800/50 rounded-lg text-slate-300 border border-slate-700 group-hover:text-white group-hover:border-slate-600 transition-colors">
            {getIcon()}
          </div>
          {trend && (
             <div className={`text-xs font-bold px-2 py-1 rounded-full bg-slate-900/50 border border-slate-800 ${trendColorClass}`}>
               {trend}
             </div>
          )}
        </div>
        
        <div>
          <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">{label}</p>
          <h3 className="text-3xl font-bold text-white tracking-tight">{value}</h3>
        </div>
      </div>
    </div>
  );
};

export default KPICard;