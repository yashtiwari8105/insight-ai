import React from 'react';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, AreaChart, Area, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell
} from 'recharts';
import { ChartConfig } from '../types';
import { CHART_COLORS } from '../constants';

interface ChartRendererProps {
  config: ChartConfig;
  index: number;
}

const ChartRenderer: React.FC<ChartRendererProps> = ({ config, index }) => {
  const { type, data, title, description, dataKey, xAxisKey } = config;

  const color = CHART_COLORS[index % CHART_COLORS.length];

  // Common props for consistency
  const gridStroke = "#334155"; // slate-700
  const axisColor = "#94a3b8"; // slate-400
  const tooltipStyle = {
    backgroundColor: '#0f172a', // slate-950
    borderColor: '#1e293b', // slate-800
    color: '#f1f5f9', // slate-100
    borderRadius: '8px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.5)',
  };

  const renderChart = () => {
    switch (type) {
      case 'bar':
        return (
          <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridStroke} opacity={0.4} />
            <XAxis dataKey={xAxisKey} axisLine={false} tickLine={false} tick={{ fill: axisColor, fontSize: 11 }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: axisColor, fontSize: 11 }} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: 'rgba(255,255,255,0.05)' }} />
            <Bar dataKey={dataKey} fill={color} radius={[4, 4, 0, 0]} />
          </BarChart>
        );
      case 'line':
        return (
          <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridStroke} opacity={0.4} />
            <XAxis dataKey={xAxisKey} axisLine={false} tickLine={false} tick={{ fill: axisColor, fontSize: 11 }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: axisColor, fontSize: 11 }} />
            <Tooltip contentStyle={tooltipStyle} />
            <Line 
              type="monotone" 
              dataKey={dataKey} 
              stroke={color} 
              strokeWidth={3} 
              dot={{ r: 4, fill: '#0f172a', strokeWidth: 2, stroke: color }} 
              activeDot={{ r: 6, fill: color, stroke: '#fff' }} 
            />
          </LineChart>
        );
      case 'area':
        return (
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id={`color${index}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.4}/>
                <stop offset="95%" stopColor={color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridStroke} opacity={0.4} />
            <XAxis dataKey={xAxisKey} axisLine={false} tickLine={false} tick={{ fill: axisColor, fontSize: 11 }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: axisColor, fontSize: 11 }} />
            <Tooltip contentStyle={tooltipStyle} />
            <Area type="monotone" dataKey={dataKey} stroke={color} fillOpacity={1} fill={`url(#color${index})`} />
          </AreaChart>
        );
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={5}
              dataKey={dataKey}
              nameKey={xAxisKey}
              stroke="none"
            >
              {data.map((entry, i) => (
                <Cell key={`cell-${i}`} fill={CHART_COLORS[i % CHART_COLORS.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={tooltipStyle} />
            <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ color: '#94a3b8' }}/>
          </PieChart>
        );
      case 'scatter':
        return (
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: -20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} opacity={0.4} />
            <XAxis type="category" dataKey={xAxisKey} name={xAxisKey} tick={{ fill: axisColor, fontSize: 11 }} dy={10} />
            <YAxis type="number" dataKey={dataKey} name={dataKey} tick={{ fill: axisColor, fontSize: 11 }} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ strokeDasharray: '3 3' }} />
            <Scatter name={title} data={data} fill={color} />
          </ScatterChart>
        );
      default:
        return <div className="text-slate-500 p-4">Unsupported chart type</div>;
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6 h-full flex flex-col hover:border-blue-500/30 transition-all duration-300 group">
      <div className="mb-6">
        <h3 className="text-lg font-bold text-slate-100 group-hover:text-blue-300 transition-colors">{title}</h3>
        <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-semibold">{description}</p>
      </div>
      <div className="flex-1 w-full min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ChartRenderer;