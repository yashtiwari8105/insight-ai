import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ANALYSIS_SYSTEM_INSTRUCTION = `
You are a world-class Data Storyteller and Business Intelligence Expert. 
Your goal is to transform raw CSV data into a high-impact, executive-level dashboard.

Rules:
1. Analyze the provided CSV data patterns, headers, and values.
2. Identify Key Performance Indicators (KPIs) that matter most.
3. AGGREGATE the data yourself. Calculate sums, averages, or counts.
4. **STYLE**: Use "Impactful" and "Direct" language. Avoid fluff. Make the summary feel like a strategic briefing.
5. **VISUALIZATION**: Choose charts that reveal hidden patterns. Limit to 6 key charts.
6. Limit chart data points to 10-20 items for clarity.
7. Return a JSON object strictly adhering to the schema.
`;

export const analyzeCsvData = async (csvText: string): Promise<AnalysisResult> => {
  try {
    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        dashboardTitle: { type: Type.STRING, description: "A punchy, headline-style title for the analysis." },
        summary: { type: Type.STRING, description: "A high-level strategic narrative summarizing the 'story' of the data. 2-3 paragraphs." },
        kpis: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING },
              value: { type: Type.STRING, description: "Formatted value (e.g. '$1.2M', '450')" },
              trend: { type: Type.STRING, description: "Trend description e.g. '+12% vs avg'" },
              trendColor: { type: Type.STRING, enum: ['green', 'red', 'neutral'] },
              icon: { type: Type.STRING, enum: ['dollar', 'users', 'trend', 'activity', 'box'] }
            },
            required: ['label', 'value', 'trendColor']
          }
        },
        charts: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['bar', 'line', 'pie', 'area', 'scatter'] },
              xAxisKey: { type: Type.STRING },
              dataKey: { type: Type.STRING },
              data: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: {type: Type.STRING},
                    value: {type: Type.NUMBER}
                  }
                }
              }
            },
            required: ['title', 'type', 'data', 'xAxisKey', 'dataKey']
          }
        },
        recommendations: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "List of 4-5 strategic, actionable steps."
        }
      },
      required: ['dashboardTitle', 'summary', 'kpis', 'charts', 'recommendations']
    };

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { text: "Analyze this dataset and provide a strategic dashboard configuration:" },
        { text: csvText }
      ],
      config: {
        systemInstruction: ANALYSIS_SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.3, 
      }
    });

    const resultText = response.text;
    if (!resultText) throw new Error("No response from AI");

    return JSON.parse(resultText) as AnalysisResult;

  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};